Requirements:

- A Windows PE USB (Windows 8 or newer)
- The executable itself (put it in c:\)

When you boot from the Windows PE USB on the taget machine, press SHIFT F10 and type:

cd /d "C:\"
account-pirate-x64.exe

And the tool should load. Please take the legal diclaimer in consideration before proceeding.