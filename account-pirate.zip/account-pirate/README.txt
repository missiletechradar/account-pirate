Requirements:

- A Windows PE USB (Windows 8 or newer) or Windows Recovery enviorement
- The executable itself (put it in c:\) or any directory you can find it easily)

When you boot from the Windows PE USB on the taget machine, press SHIFT F10 and type:

- Only specify /d if it's on another drive letter

cd /d "d:\path\to\account-pirate"
account-pirate-x64.exe

And the tool should load. Please take the legal diclaimer in consideration before proceeding.